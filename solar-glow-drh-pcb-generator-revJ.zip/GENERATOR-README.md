# SOLAR-GLOW · DRH — REV J board generator (source)

This is the generator that produced the **ordered REV J** board. It is the parametric,
Shapely-based artwork + placement + router, plus a Gerber/Excellon exporter.

## Provenance (verified)

Running `gerber_export.py` regenerates the **nine ordered gerbers byte-for-byte identical** to
`solar-glow-drh-gerbers-revJ.zip` (ignoring only `G04` comment/timestamp lines):
`*.GTL .GBL .GTO .GBO .GTS .GBS .GKO` and both drills (`.XLN`, `NPTH.XLN`). DRC is clean
(all nets connected, no clearance violations). This is unambiguously REV J — four **independent**
LED PWM channels (L2–L5 on PC0/PB0/PB1/PB2) and ballasts at x = 18.2 / 23 / 27.8 / 32.6
(REV I was single-`LRET`, ballasts at 13.7 / 21.7 / 29.1 / 37.1).

## Files

- `pcb_route.py` — geometry, footprints (`FP`), placement + netlist, router, DRC. Importable as a
  module: exposes `pad_xy[(ref,pin)] -> (x, y, side)`, `pad_net[(ref,pin)] -> net`, `W` (board width).
- `gerber_export.py` — emits the 9 gerbers to `OUT` and renders a preview PNG. **Imports `pcb_route`
  as `pr`.** Both run top-to-bottom on import (no `__main__` guard).
- `qr_front.py`, `qr_back.py` — QR code geometry (front/back).
- `logos.py`, `logos_cache.wkt` — logo/monogram polygon geometry + cache.
- `rg.py` — helper.
- `fonts/` — **JetBrains Mono** (Regular/Medium/SemiBold/Bold/ExtraBold), used for the monogram /
  text. JetBrains ships it under the **SIL Open Font License 1.1**, which permits redistribution —
  fine to commit alongside an `OFL.txt` (from the JetBrainsMono release). Confirm the license file
  is included if you publish.

## Run

```sh
python gerber_export.py     # writes gerbers to OUT, plus a preview PNG
```

`OUT` is set near the top of `gerber_export.py` (currently an absolute scratch path) — point it at
your local gerber output dir. Deps: Python 3, `shapely` (router/geometry), `matplotlib` (preview),
`gerbonara` (the post-export parse-check at the bottom of `gerber_export.py`).

## Scope note

The hand-coded Shapely route is the right tool for **artwork / placement / layout prototyping**.
For *final* copper sign-off on a board this dense, the plan is to move routing to **KiCad** with real
footprints + DRC (V1-PLAN §4). Recovering this source means the supercap part swap / any land tweak
can be done here and regenerated directly, without first rebuilding in KiCad.
