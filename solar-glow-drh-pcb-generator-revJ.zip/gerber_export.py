#!/usr/bin/env python3
"""Export OSH-Park Gerbers + Excellon from the FROZEN pcb_route geometry.
Layers: GTL/GBL copper, GTS/GBS soldermask openings, GKO outline, XLN drill.
Beauty mask features included: front vCard QR, back GitHub QR (mirrored for
bottom-side readability), front LED glow windows, small ENIG name caption.
Renders an as-fabricated preview (black mask / gold ENIG / bare-FR4 glow)."""
import os, math, numpy as np
from functools import reduce
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.textpath import TextPath
from matplotlib.font_manager import FontProperties
from matplotlib.path import Path as MP
from shapely.geometry import Polygon as SPoly, Point, box, MultiPolygon, LineString
from shapely.ops import unary_union
import shapely.affinity as aff

import pcb_route as pr           # frozen route: build_copper, build_pours, abs_pads, VIAS, P
import logos                     # alma-mater logos -> back mask openings (gold seal/hex over GND pour)
from qr_front import QNF, QDARKF
from qr_back  import QN,  QDARK

W,H,R = pr.W, pr.H, pr.R
OUT="/home/claude/gerber"; os.makedirs(OUT, exist_ok=True)
JBM = FontProperties(fname="/home/claude/fonts/JetBrainsMono-Bold.ttf")
JBM_R = FontProperties(fname="/home/claude/fonts/JetBrainsMono-Regular.ttf")  # lighter strokes for contact details -> wider intra-glyph mask dams

# ---------- geometry helpers ----------
def text_shapely(txt, cx, cy, h, ha="center", track=0.04, prop=JBM):
    S=72.0; adv=S*(0.6+track); vv=[]; cc=[]; xo=0.0
    for ch in txt:
        if ch!=" ":
            t=TextPath((0,0),ch,size=S,prop=prop)
            if len(t.vertices): vv.append(t.vertices+[xo,0]); cc.append(t.codes)
        xo+=adv
    path=MP(np.vstack(vv),np.concatenate(cc))
    contours=[c for c in path.to_polygons(closed_only=True) if len(c)>=4]
    polys=[SPoly(c).buffer(0) for c in contours]
    geom=reduce(lambda a,b:a.symmetric_difference(b), polys)
    minx,miny,maxx,maxy=geom.bounds; sc=h/(maxy-miny)
    geom=aff.scale(geom,xfact=sc,yfact=sc,origin=(minx,miny))
    minx,miny,maxx,maxy=geom.bounds
    dx={"center":cx-(minx+maxx)/2,"left":cx-minx,"right":cx-maxx}[ha]
    return aff.translate(geom, dx, cy-(miny+maxy)/2)

def name_line(cx, cy, h, track=0.04, gap=0.40, uw=0.12, ud=0.34, prop=JBM):
    """'Devin @ Horowitz.Law' as one consistently-scaled line (slight @ gaps) +
    a trace-style underline under just 'Horowitz.Law'. Returns (text, underline)."""
    S=72.0; adv=S*(0.6+track); gpx=gap*adv
    segs=["Devin","@","Horowitz.Law"]; vv=[]; cc=[]; xo=0.0; hs=he=None
    for si,txt in enumerate(segs):
        if si>0: xo+=gpx
        if txt=="Horowitz.Law": hs=xo
        for ch in txt:
            t=TextPath((0,0),ch,size=S,prop=prop)
            if len(t.vertices): vv.append(t.vertices+[xo,0]); cc.append(t.codes)
            xo+=adv
        if txt=="Horowitz.Law": he=xo
    path=MP(np.vstack(vv),np.concatenate(cc))
    contours=[c for c in path.to_polygons(closed_only=True) if len(c)>=4]
    polys=[SPoly(c).buffer(0) for c in contours]
    geom=reduce(lambda a,b:a.symmetric_difference(b), polys)
    minx,miny,maxx,maxy=geom.bounds; sc=h/(maxy-miny)
    geom=aff.scale(geom,xfact=sc,yfact=sc,origin=(minx,miny))
    minx2,miny2,maxx2,maxy2=geom.bounds
    dx=cx-(minx2+maxx2)/2; dy=cy-(miny2+maxy2)/2
    geom=aff.translate(geom,dx,dy)
    mapx=lambda X: minx+(X-minx)*sc+dx
    uy=(cy-h/2)-ud
    underline=LineString([(mapx(hs),uy),(mapx(he),uy)]).buffer(uw, cap_style=1, join_style=1)
    return geom, underline

def qr_shapely(dark, N, cx, cy, S):
    ms=S/N; tile=box(cx-S/2,cy-S/2,cx+S/2,cy+S/2)
    darks=[box(cx-S/2+c*ms, cy+S/2-(r+1)*ms, cx-S/2+(c+1)*ms, cy+S/2-r*ms) for (r,c) in dark]
    return tile.difference(unary_union(darks))

# ---------- assemble layers ----------
CLR = pr.CLR
cu = pr.build_copper(0.0); pours = pr.build_pours()
def layer_cu(lay): return unary_union([g for (n,l),g in cu.items() if l==lay]+[pours[lay]])
Fcu, Bcu = layer_cu("F"), layer_cu("B")

# rounded board outline + clips
outline = box(0,0,W,H).buffer(-R,join_style=1,resolution=20).buffer(R,join_style=1,resolution=20)
cu_clip = outline.buffer(-0.38)   # 15 mil copper-to-edge (OSH recommended)

# ---------- self-framing breakout panel: frame + top/bottom mouse-bite breakaway tabs ----------
# OSH Park pools the board and adds ITS OWN breakaway tabs to the outermost outline wherever it likes.
# Framing the card steers those onto a sacrificial frame (discarded), leaving only our own two tabs on the
# card -- on the short top/bottom edges (top = least handled, bottom = least visible; short edges sand cleanest).
MOAT_W, RAIL_W, TAB_W = 2.4, 3.0, 3.0   # moat(slot) width / frame rail width / breakaway-bridge width (mm)
MB_D, MB_PITCH, MB_N  = 0.5, 0.8, 4     # mouse-bite hole dia / pitch / count per tab
# NOTE: MOAT_W must be >= OSH Park min routed-slot / router-bit width -- CONFIRM before fab (widen if needed).
_mo = outline.buffer(MOAT_W)                                   # frame inner edge = card grown by the moat
_mb = _mo.bounds
frame_outer = box(_mb[0]-RAIL_W,_mb[1]-RAIL_W,_mb[2]+RAIL_W,_mb[3]+RAIL_W)
_tab_strip  = box(W/2-TAB_W/2,-RAIL_W-MOAT_W-1, W/2+TAB_W/2, H+RAIL_W+MOAT_W+1)   # vertical bridge column at x=W/2
moat_slots  = _mo.difference(outline).difference(_tab_strip)   # annular moat minus the 2 bridges -> left+right slots
panel_solid = frame_outer.difference(moat_slots)               # one piece: frame+card+tabs, moat = interior holes
mb_holes    = [(W/2+(i-(MB_N-1)/2)*MB_PITCH, yedge, MB_D) for yedge in (H,0.0) for i in range(MB_N)]  # straddle each card edge

# ---------- 4x M2 enclosure mounting holes (GROUNDED): symmetric 43.8 x 56 rect; PV1+supercaps block the top, so the upper pair sits at y59 ----------
MOUNT_D  = 2.2                                                                                   # M2 clearance hole, plated -> grounded both sides
mount_xy = [(3.5,3.0),(47.3,3.0),(3.5,59.0),(47.3,59.0)]
mount_ring = unary_union([Point(x,y).buffer(MOUNT_D/2+0.7,resolution=32) for x,y in mount_xy])   # O3.6 GND annular land
mount_mask = unary_union([Point(x,y).buffer(MOUNT_D/2+0.6,resolution=32) for x,y in mount_xy])   # O3.4 mask opening -> bare GND ring, screw bonds to GND

# ===== F12340 snap-dome exact footprint (SW1 @ 40.4,11; KiCad Y-down -> board Y-up) =====
sx,sy = 40.4, 11.0
def _bd(fx,fy): return (sx+fx, sy-fy)
pad1 = Point(sx,sy).buffer(2.45,resolution=48).union(box(sx+2.362, sy-0.65, sx+5.59, sy+0.65))   # RET center+tab
_p2=[(-5.59,-8.46),(-5.59,-0.94),(-3.76,0.89),(3.76,0.89),(5.59,-0.94),(5.59,-3.542),(3.74,-3.542),
     (3.74,-1.71),(2.99,-0.96),(-2.99,-0.96),(-3.74,-1.71),(-3.74,-7.69),(-2.99,-8.44),(2.99,-8.44),
     (3.74,-7.69),(3.74,-5.858),(5.59,-5.858),(5.59,-8.46),(3.76,-10.29),(-3.76,-10.29)]
pad2 = SPoly([_bd(x,y+4.7) for x,y in _p2]).buffer(0)                                             # GND horseshoe (pad anchor 0,4.7)
_oc=[(-5.59,-3.76),(-5.59,3.76),(-3.76,5.59),(3.76,5.59),(5.59,3.76),(5.59,-3.76),(3.76,-5.59),(-3.76,-5.59)]
dome_oct = SPoly([_bd(x,y) for x,y in _oc]).buffer(0)                                             # F.Mask octagon
NP_HOLE = (sx-2.5, sy+2.5, 0.89)                                                                  # non-plated vent
# swap simplified dome copper for the real pads: isolate RET pad1 (+tab), carve the bare-FR4
# gaps inside the octagon, and keep GND pad2 continuous with the surrounding pour.
pad1c = pad1.buffer(pr.POUR_CLR)
fr4_gaps = dome_oct.difference(pad2).difference(pad1c)
Fcu = Fcu.difference(pad1c).difference(fr4_gaps).union(pad1).union(pad2)

# ===== front DRH light window (bare FR4: cut copper + open mask) centered over the LEDs =====
JBM_XB = FontProperties(fname="/home/claude/fonts/JetBrainsMono-ExtraBold.ttf")
drh = text_shapely("DRH", 25.4, 45.0, 5.5, track=0.12, prop=JBM_XB)
Fcu = Fcu.difference(drh)

# ===== rear light-entry holes (cut back copper + open back mask) at the four LEDs =====
led_xy=[(ox,oy) for (ref,k,ox,oy,rd,s,nm) in pr.P if k=="LED"]
back_holes=[Point(x,y).buffer(0.82,resolution=40) for x,y in led_xy]; back_holes_u=unary_union(back_holes)   # r0.82 clears the LED pad inner corner (0.976) by >0.15mm: pads intact, no window-pad necks, ~1.64mm light aperture
Bcu = Bcu.difference(back_holes_u)
Bcu = Bcu.difference(Point(NP_HOLE[0],NP_HOLE[1]).buffer(NP_HOLE[2]/2 + 0.25, resolution=32))   # clear back pour around the non-plated dome vent (else the 0.89mm drill tears solid copper)

# ===== PV1 GND-pad thermal relief: the cell is hand-solder only (no reflow), so isolate the (-) contact + its
# access tab from the GND pour and reconnect with two narrow spokes, so an iron can bring the joint to temp. =====
_pvn   = Point(7.4,73.0).buffer(3.5/2,resolution=32).union(box(2.3,71.5,6.3,74.5))          # (-) contact + left access tab
_pvnsp = unary_union([box(7.4-0.25,73.0,7.4+0.25,76.2), box(7.4-0.25,69.8,7.4+0.25,73.0)])  # N/S spokes, 0.5mm wide
Fcu = Fcu.difference(_pvn.buffer(0.4).difference(_pvn).difference(_pvnsp))                   # 0.4mm relief moat minus the spokes

Fcu = Fcu.intersection(cu_clip); Bcu = Bcu.intersection(cu_clip)
# ===== castellated edge teeth: plated pads must reach the board edge (exempt from the 0.38mm cu_clip inset) =====
cast_pad_u = unary_union([Point(x,y).buffer(pr.CAST_PAD/2,resolution=24) for net,x,y in pr.CAST]).intersection(outline)
Fcu = Fcu.union(cast_pad_u); Bcu = Bcu.union(cast_pad_u)
Fcu = Fcu.union(mount_ring); Bcu = Bcu.union(mount_ring)   # grounded mount lands merge into the GND pour (both layers)

# ---------- mask openings ----------
def pad_ops(lay, g=0.05):
    ops=[]
    for ref,pn,net,x,y,w,h,sh,side in pr.abs_pads:
        if ("F" if side=="F" else "B")!=lay: continue
        if ref=="SW1": continue                        # dome opening handled by the octagon
        if ref=="U1": continue                         # QFN -> single mask window (qfn_win) instead of 20 openings w/ 0.05mm webs
        if sh in ("o","ring"): ops.append(Point(x,y).buffer(w/2+g,resolution=24))
        elif sh=="rr":
            r=min(w,h)*0.30
            ops.append(box(x-w/2+r,y-h/2+r,x+w/2-r,y+h/2-r).buffer(r,join_style=1,resolution=16).buffer(g,join_style=1))
        else: ops.append(box(x-w/2-g,y-h/2-g,x+w/2+g,y+h/2+g))
    return ops

# QR light modules -> emitted as individual aperture flashes (robust/complete on the fab)
def qr_light(dark, N, cx, cy, S, mirror=False, qz=2):   # qz extra light rings -> total quiet zone = 2 built-in + qz = 4
    ms=S/N; dk=set(dark); out=[]
    for r in range(-qz, N+qz):
        for c in range(-qz, N+qz):
            if 0<=r<N and 0<=c<N and (r,c) in dk: continue   # dark data module -> no light flash
            x=cx-S/2+(c+0.5)*ms; y=cy+S/2-(r+0.5)*ms
            if mirror: x=W-x
            out.append((round(x,5),round(y,5),round(ms*1.04,5)))
    return out
qrF = qr_light(QDARKF, QNF, 13.5, 14.0, 16.0)
qrB = qr_light(QDARK,  QN,  20.3, 14.0, 12.0, mirror=True)
def qr_boxes(mods): return unary_union([box(x-s/2,y-s/2,x+s/2,y+s/2) for x,y,s in mods])
def round_corners(geom, r):
    mnx,mny,mxx,mxy=geom.bounds
    return geom.intersection(box(mnx+r,mny+r,mxx-r,mxy-r).buffer(r,join_style=1,resolution=16))
qrF_g = round_corners(qr_boxes(qrF), 1.6*16.0/QNF)   # round only outer quiet-zone corners; finder patterns + data untouched
qrB_g = round_corners(qr_boxes(qrB), 1.6*12.0/QN)

# gold contact block (mask openings over the GND pour), centered, below the TP line
nm_txt, nm_uline = name_line(25.4, 33.5, 2.05, track=0.08, gap=0.40)
contact = unary_union([
    nm_txt, nm_uline,
    text_shapely("Attorney",     25.4, 30.2, 1.6, track=0.08, prop=JBM_R),
    text_shapely("404-213-8076", 25.4, 27.6, 1.6, track=0.08, prop=JBM_R),
])
# functional gold accents: expose the front VIN trace (right) + GND-pour strip (left), via-dots at the ends
acc_vin  = LineString([(43.4,73.0),(45.4,73.0),(45.4,40.0)]).buffer(0.22, cap_style=2, join_style=1)
acc_gnd  = LineString([(7.4,73.0),(5.4,73.0),(5.4,40.0)]).buffer(0.22, cap_style=2, join_style=1)
accents  = unary_union([acc_vin, acc_gnd])   # stripes now lead into TP6/TP7 in the row; standalone via-dots removed
# top silkscreen (GTO): test-point net labels below the pads
TPL = [("GND",5.9),("GND",18.9),("GND",31.9),("VS",38.4),("VIN",44.9)]
solar_pol = unary_union([text_shapely("+",43.4,70.5,1.2,prop=JBM_XB), box(7.4-0.5,70.5-0.14,7.4+0.5,70.5+0.14)])  # '-' as an explicit bar; text_shapely mis-scales a lone hyphen (scales by glyph height -> fat block)
silk = unary_union([text_shapely(lbl, x, 37.6, 0.70, track=0.04, prop=JBM_XB) for lbl,x in TPL]+[solar_pol]
        ).intersection(outline)   # 7-pt row; leftmost (5.9) is an unlabeled GND probe (TP2 GND adjacent, '-' mark above it)
# ---- REV J battery-option silk (front): one-source warning + refs + diode cathode bars ----
batt_silk = unary_union([
    aff.rotate(text_shapely("SOLAR or BATTERY, NOT BOTH", 25.4, 73.0, 1.0, track=0.06, prop=JBM_XB), 90, origin=(25.4,73.0)),  # vertical, between BT1 and BT2
    text_shapely("BT1",17.4,86.3,0.8,prop=JBM_XB), text_shapely("BT2",33.4,86.3,0.8,prop=JBM_XB),
]).intersection(outline)   # D6/D7/C4 refs + cathode bars moved to the back (parts are rear now)
sw1_mode = aff.rotate(text_shapely("DOME or TOUCH", 33.0, 11.0, 0.85, track=0.05, prop=JBM_XB), 90, origin=(33.0,11.0))  # vertical, left of dome: build-time choice (snap-dome switch OR bare cap-touch pad on PA7)
silk = unary_union([silk, batt_silk, sw1_mode, text_shapely("SW1",40.4,4.8,0.7,prop=JBM_XB)])   # SW1 dome ref (was unlabeled)
silk = silk.buffer(0.013).buffer(0)   # thicken strokes toward OSH 6mil silk minimum
# ===== bottom silkscreen (GBO): refs / pin-1 / cathode / J1 pinout / title (glyphs mirrored to read from the back) =====
def bsilk(txt, cx, cy, h, track=0.05):
    return aff.scale(text_shapely(txt,cx,cy,h,track=track,prop=JBM_XB), xfact=-1, yfact=1, origin=(cx,cy))
RB=0.62
back_refs = unary_union([
    bsilk("SC1",15.5,73.2,RB), bsilk("SC2",35.3,73.2,RB),
    bsilk("D2",18.2,43.6,RB), bsilk("D3",23.0,43.6,RB), bsilk("D4",27.8,43.6,RB), bsilk("D5",32.6,43.6,RB),  # LED refs: central band, below the LEDs
    bsilk("R1",18.2,42.6,RB), bsilk("R2",23.0,42.6,RB), bsilk("R3",27.8,42.6,RB), bsilk("R4",32.6,42.6,RB),  # resistor refs: central band, above the resistors
    bsilk("D1",30.0,36.6,RB), bsilk("C2",22.0,36.6,RB), bsilk("C3",37.5,36.6,RB),                            # CHARGE refs: top band, above their parts
    bsilk("U1",11.5,23.6,RB), bsilk("C1",9.0,25.2,0.5),
    bsilk("J1",6.6,31.8,RB), bsilk("JP1",38.0,31.8,RB), bsilk("U2",24.5,50.7,RB),
])
u2_pin1 = Point(26.2,52.6).buffer(0.28,resolution=16)                # U2 pin-1 dot
u1_pin1 = Point(9.2,28.8).buffer(0.30,resolution=16)                 # QFN pin-1 dot
d1_cath = box(27.0,34.85,27.45,36.15)                                # D1 cathode bar (K side)
# polarity marks (white silk): supercap + terminals, and LED anodes (LA P47F has an anode marking; A=VS pad)
PLUS = 0.85
polarity = unary_union([
    bsilk("+",21.75,54.0,PLUS), bsilk("+",29.05,81.0,PLUS),          # SC1 / SC2 positive pads
    bsilk("+",16.2,45.4,0.55), bsilk("+",21.1,45.4,0.55),           # D2 / D3 anode (left pad) - clear of pads
    bsilk("+",25.9,45.4,0.55), bsilk("+",30.7,45.4,0.55),           # D4 / D5 anode (left pad) - clear of pads
])
j1_pins = unary_union([bsilk("UPDI",8.5,29.54,0.55), bsilk("VCC",8.5,27.0,0.55), bsilk("GND",4.8,24.46,0.55)])  # GND label moved left of pin3 (C1's VS pad now sits below the old spot)
jp1_pins = unary_union([bsilk("SDA",35.5,28.54,0.55), bsilk("SCL",35.5,26.0,0.55), bsilk("GND",35.5,23.46,0.55)])  # JP1 = I2C breakout (pin1 top); inner side, clears QR below + pads
back_title = unary_union([bsilk("SOLAR-GLOW",15.5,5.6,0.85), bsilk("DRH v0",15.5,3.5,0.85)])  # nudged down to clear the 15mm shield above
cast_lbls = unary_union([bsilk(net,48.0,y,0.5) for net,x,y in pr.CAST])   # edge-tooth net labels (inboard of the pads)
# REV J: rear battery parts (D6/D7 in the SC1/SC2 gap, C4 on the VS bus) — refs + diode cathode bars
batt_back = unary_union([bsilk("D6",25.4,79.0,0.5), bsilk("D7",25.4,66.5,0.5), bsilk("C4",14.5,52.5,0.5),
    box(25.4-0.7,73.5-0.07,25.4+0.7,73.5+0.07), box(25.4-0.7,67.5-0.07,25.4+0.7,67.5+0.07)])  # D6/D7 cathode bars (K = bottom)
zone_lbls = unary_union([bsilk("ENERGY STORE",24.0,85.4,0.6), bsilk("PWM LEDS",25.4,46.4,0.6), bsilk("BALANCER",15.2,48.6,0.5), bsilk("MCU",11.5,31.5,0.5)])  # functional zone labels
back_silk = unary_union([back_refs,u1_pin1,u2_pin1,d1_cath,polarity,j1_pins,jp1_pins,back_title,cast_lbls,batt_back,zone_lbls]).intersection(outline)

# ===== functional-block framing (back): solid corner ticks + sparse dotted fill + block labels =====
def _ticks(bx, leg=1.35, w=0.16):
    mnx,mny,mxx,mxy=bx; o=[]
    for cx,cy,sx,sy in [(mnx,mny,1,1),(mxx,mny,-1,1),(mnx,mxy,1,-1),(mxx,mxy,-1,-1)]:
        hx=sorted([cx,cx+sx*leg]); vy=sorted([cy,cy+sy*leg])
        o.append(box(hx[0],cy-w/2,hx[1],cy+w/2)); o.append(box(cx-w/2,vy[0],cx+w/2,vy[1]))
    return unary_union(o)
def _dots(bx, keep, pitch=1.5, r=0.15):
    mnx,mny,mxx,mxy=bx; o=[]; y=mny+pitch
    while y<mxy-pitch*0.4:
        x=mnx+pitch
        while x<mxx-pitch*0.4:
            d=Point(x,y).buffer(r,resolution=10)
            if not d.intersects(keep): o.append(d)
            x+=pitch
        y+=pitch
    return unary_union(o) if o else box(0,0,0,0)
# block boxes: ENERGY STORE, BALANCER, PWM LEDS, CHARGE(D1/C2/C3), MCU(+J1), I2C(JP1)
SECT=[(6.5,53.0,44.3,86.3),(13.4,48.2,33.6,53.0),(14.8,37.7,35.6,47.0),(19.5,34.0,40.0,37.0),(4.5,22.8,13.6,30.8),(35.6,22.3,40.4,29.7)]
_padB=unary_union(pad_ops("B"))
sect_ticks=unary_union([_ticks(b) for b in SECT]).difference(_padB).difference(back_silk.buffer(0.22))        # keep ticks off pads
sect_lbls=unary_union([bsilk("CHARGE",16.5,35.5,0.5), bsilk("I2C EXPANSION",35.8,33.7,0.46)])
annot=unary_union([
    bsilk("UPDI PROG",8.5,33.7,0.45),                         # J1 = intentional UPDI programming port (flash U1)
    bsilk("5.5V 150mF",13,64,0.5), bsilk("2x 2.75V 300mF",13,61.8,0.42),  # supercap stack rating
    bsilk("1k x4",38.5,41,0.42),                               # LED ballast value
])
leaders=unary_union([
    LineString([(8.5,33.3),(6.8,30.1)]).buffer(0.07,cap_style=2),
    LineString([(35.8,33.3),(36.2,29.5)]).buffer(0.07,cap_style=2),
    LineString([(46.1,33),(47.7,31.2)]).buffer(0.07,cap_style=2)
])
cast_note=bsilk("I2C + PWR",43.5,33,0.42)
back_silk = unary_union([back_silk, sect_ticks, sect_lbls, annot, leaders, cast_note]).intersection(outline)
back_silk = back_silk.buffer(0.013).buffer(0)   # thicken thin back-label strokes toward OSH 6mil silk minimum

Fmask_noqr = unary_union(pad_ops("F")+[dome_oct, drh, contact]).intersection(outline)   # accents dropped -> the two solar-lead traces are covered by mask
qfn_win = box(11.5-1.8, 27.0-1.8, 11.5+1.8, 27.0+1.8)   # single QFN mask window (covers pads ±1.725, inside the 0.16mm pour clearance)
cast_mask = unary_union([Point(x,y).buffer(pr.CAST_PAD/2+0.05,resolution=24) for net,x,y in pr.CAST]).intersection(outline)
Fmask_noqr = Fmask_noqr.union(cast_mask)
Bmask_noqr = unary_union(pad_ops("B")+back_holes+[qfn_win, logos.back_logos()]).intersection(outline).union(cast_mask)
# ---------- grounded mount-ring openings + perimeter frame -> EMITTED on BOTH layers (these previously went only into the preview mask, so OSH Park saw neither) ----------
Fmask_noqr = Fmask_noqr.union(mount_mask); Bmask_noqr = Bmask_noqr.union(mount_mask)   # expose the grounded mount rings, both sides

# exposed-copper perimeter frame (BOTH sides): grounded gold border peeking out around the panel, with EQUAL rounded gaps wherever it crosses an obstruction
BORDER_W, BORDER_INSET, BORDER_GAP = 1.2, 0.5, 0.65                                    # 1.2mm frame, outer edge 0.5mm from board edge (in the GND pour); 0.65mm purple gap at each obstruction (uniform)
_bc    = outline.buffer(-(BORDER_INSET+BORDER_W/2)).exterior                           # frame centreline (rounded-rect loop)
_obstr = unary_union([Point(x,y).buffer(MOUNT_D/2+0.6,resolution=32) for x,y in mount_xy]         # 4 grounded mount-ring openings (O3.4)
        + [Point(x,y).buffer(pr.CAST_PAD/2+0.05,resolution=24) for net,x,y in pr.CAST])           # 5 right-edge castellation openings (O1.65)
_seg   = _bc.difference(_obstr.buffer(BORDER_GAP + BORDER_W/2))                        # cut the centreline so every rounded cap lands BORDER_GAP from the obstruction -> equal gaps
border = _seg.buffer(BORDER_W/2, cap_style=1, join_style=1).intersection(outline)      # round caps (no sharp square ends) + round joins (smooth corners)
Fmask_noqr = Fmask_noqr.union(border); Bmask_noqr = Bmask_noqr.union(border)           # grounded gold frame on both layers
# mid-border: grounded gold bar on the y59 screw line (FRONT only), walling off the solar/battery zone from the electronics
_mids=[(3.5,59.0),(47.3,59.0)]
_mbseg=LineString([_mids[0],_mids[1]]).difference(unary_union([Point(x,y).buffer(MOUNT_D/2+0.6,resolution=32) for x,y in _mids]).buffer(BORDER_GAP+BORDER_W/2))
midbar=_mbseg.buffer(BORDER_W/2,cap_style=1,join_style=1).intersection(outline)
Fmask_noqr=Fmask_noqr.union(midbar)   # front only (back y59 is under the supercaps)

# preview-only full masks (QR rendered as merged boxes) — now mirror the emitted gerbers exactly
Fmask = unary_union([Fmask_noqr, qrF_g]).intersection(outline)
Bmask = unary_union([Bmask_noqr, qrB_g]).intersection(outline)
# never print silk over exposed copper (pads, gold art, frame, vias) -> OSH-safe
silk = silk.difference(Fmask.buffer(0.10))
back_silk = back_silk.difference(Bmask.buffer(0.10))

# ---------- RS-274X emit (regions: LPD exteriors + LPC holes) ----------
def C(v): return str(int(round(v*1e6)))
def ring(coords):
    pts=list(coords)
    if pts and pts[0]==pts[-1]: pts=pts[:-1]
    out=[f"X{C(pts[0][0])}Y{C(pts[0][1])}D02*"]
    out+= [f"X{C(x)}Y{C(y)}D01*" for (x,y) in pts[1:]]
    out.append(f"X{C(pts[0][0])}Y{C(pts[0][1])}D01*"); return out
def polys_of(geom):
    if geom.is_empty: return []
    gt=geom.geom_type
    if gt=="Polygon": return [geom]
    out=[]
    if gt in ("MultiPolygon","GeometryCollection"):
        for g in geom.geoms:
            if g.geom_type=="Polygon" and not g.is_empty: out.append(g)
            elif g.geom_type=="MultiPolygon": out+=[p for p in g.geoms if not p.is_empty]
    return out
def emit_fill(fn, geom, ff):
    # Process polygons largest-area first and interleave polarity PER polygon:
    # draw exterior (LPD) then immediately clear its own holes (LPC). A polygon nested
    # inside another's hole (a copper island in a pour void, the gold detail inside the
    # heraldry, a letter's counter) is therefore repainted AFTER the containing hole was
    # cleared, instead of being wiped by an all-holes-last pass.
    L=[f"%TF.FileFunction,{ff}*%","%FSLAX46Y46*%","%MOMM*%","G01*"]
    for pl in sorted(polys_of(geom), key=lambda p: p.area, reverse=True):
        L.append("%LPD*%")
        L.append("G36*"); L+=ring(pl.exterior.coords); L.append("G37*")
        if pl.interiors:
            L.append("%LPC*%")
            for r in pl.interiors: L.append("G36*"); L+=ring(r.coords); L.append("G37*")
    L.append("M02*"); open(os.path.join(OUT,fn),"w").write("\n".join(L)+"\n")
def emit_outline(fn, geom):
    L=["%TF.FileFunction,Profile,NP*%","%FSLAX46Y46*%","%MOMM*%","%ADD10C,0.100*%","G01*","D10*"]
    for pl in polys_of(geom):                       # frame exterior + each moat slot (interior)
        for rng in [pl.exterior]+list(pl.interiors):
            pts=list(rng.coords)
            if len(pts)<2: continue
            L.append(f"X{C(pts[0][0])}Y{C(pts[0][1])}D02*")
            L+=[f"X{C(x)}Y{C(y)}D01*" for (x,y) in pts[1:]]
    L.append("M02*"); open(os.path.join(OUT,fn),"w").write("\n".join(L)+"\n")
def emit_drill(fn, vias, extra=()):
    L=["M48",";SOLAR-GLOW DRH","METRIC","G90","T1C0.300"]
    for i,(x,y,d) in enumerate(extra): L.append(f"T{2+i}C{d:.3f}")
    L+=["%","T1"]; L+=[f"X{x:.3f}Y{y:.3f}" for (net,x,y) in vias]
    for i,(x,y,d) in enumerate(extra): L.append(f"T{2+i}"); L.append(f"X{x:.3f}Y{y:.3f}")
    L.append("M30"); open(os.path.join(OUT,fn),"w").write("\n".join(L)+"\n")

emit_fill("solar-glow-drh.GTL", Fcu,  "Copper,L1,Top")
emit_fill("solar-glow-drh.GBL", Bcu,  "Copper,L2,Bot")
emit_fill("solar-glow-drh.GTS", unary_union([Fmask_noqr, qrF_g]), "Soldermask,Top")
emit_fill("solar-glow-drh.GBS", unary_union([Bmask_noqr, qrB_g]), "Soldermask,Bot")
emit_outline("solar-glow-drh.GKO", panel_solid)   # frame + card + tabs; moat slots are interiors
emit_drill("solar-glow-drh.XLN", pr.VIAS, extra=[(x,y,pr.CAST_D) for net,x,y in pr.CAST]+[(x,y,MOUNT_D) for x,y in mount_xy])   # plated vias + castellated edge holes + 4 grounded M2 mounts
# non-plated dome vent in its own file so OSH leaves it unplated
open(os.path.join(OUT,"solar-glow-drh-NPTH.XLN"),"w").write("\n".join(
    ["M48",";SOLAR-GLOW DRH non-plated","METRIC","G90",f"T1C{NP_HOLE[2]:.3f}",f"T2C{MB_D:.3f}","%",
     "T1",f"X{NP_HOLE[0]:.3f}Y{NP_HOLE[1]:.3f}","T2"]
    + [f"X{x:.3f}Y{y:.3f}" for (x,y,d) in mb_holes] + ["M30"])+"\n")
emit_fill("solar-glow-drh.GTO", silk, "Legend,Top")
emit_fill("solar-glow-drh.GBO", back_silk, "Legend,Bot")
print("emitted Gerbers:", sorted(os.listdir(OUT)))

# ---------- as-fabricated preview ----------
from matplotlib.path import Path as _MPath
from matplotlib.patches import PathPatch as _PP
def fillgeom(ax, geom, color, z, alpha=1.0):
    for pl in polys_of(geom):
        verts=[]; codes=[]
        for rng in [pl.exterior]+list(pl.interiors):
            cs=list(rng.coords)
            if len(cs)<3: continue
            verts+=cs; codes+=[_MPath.MOVETO]+[_MPath.LINETO]*(len(cs)-2)+[_MPath.CLOSEPOLY]
        if verts: ax.add_patch(_PP(_MPath(verts,codes), fc=color, ec="none", lw=0, zorder=z, alpha=alpha))
MASKC="#0a0a0c"; GOLDC="#c9a227"; FR4C="#5b4a22"
fig,(aF,aB)=plt.subplots(1,2,figsize=(9.5,9)); fig.patch.set_facecolor("#000")
for ax,cu_,mk_,slk_,ttl,mirror in [(aF,Fcu,Fmask,silk,"FRONT (as fabricated)",False),
                               (aB,Bcu,Bmask,back_silk,"BACK (viewed from back)",True)]:
    cug = aff.scale(cu_,xfact=-1,origin=(W/2,0)) if mirror else cu_
    mkg = aff.scale(mk_,xfact=-1,origin=(W/2,0)) if mirror else mk_
    slkg= aff.scale(slk_,xfact=-1,origin=(W/2,0)) if mirror else slk_
    outg= aff.scale(outline,xfact=-1,origin=(W/2,0)) if mirror else outline
    panelg= aff.scale(panel_solid,xfact=-1,origin=(W/2,0)) if mirror else panel_solid
    fillgeom(ax, panelg, FR4C, 0)                # frame rail + card + tabs = bare FR4; moat reads as background
    fillgeom(ax, outg, MASKC, 1)                 # black soldermask field over the card
    fillgeom(ax, mkg.difference(cug), FR4C, 2)   # mask open, no copper -> bare FR4 (glow)
    fillgeom(ax, cug.intersection(mkg), GOLDC, 3)# mask open over copper -> ENIG gold
    fillgeom(ax, slkg, "#e8e4d8", 4)             # silkscreen (white)
    for (hx,hy,hd) in mb_holes:                  # mouse-bite perforations on the top/bottom tabs
        ax.add_patch(plt.Circle(((W-hx) if mirror else hx, hy), hd/2, fc="#000", ec="none", zorder=5))
    for (hx,hy) in mount_xy:                     # M2 grounded mounting holes
        ax.add_patch(plt.Circle(((W-hx) if mirror else hx, hy), MOUNT_D/2, fc="#000", ec="#caa48a", lw=0.5, zorder=5))
    _pb=frame_outer.bounds
    ax.set_xlim(_pb[0]-2,_pb[2]+2); ax.set_ylim(_pb[1]-2,_pb[3]+2); ax.set_aspect("equal"); ax.axis("off")
    ax.set_title(ttl,color="#d9a23a",fontsize=11,fontproperties=JBM,pad=8)
fig.suptitle("SOLAR-GLOW · DRH — Gerber preview (std 0.8mm 2-layer: gold=ENIG, dark=mask, tan=bare-FR4 light windows)",
             color="#d9a23a",fontsize=9.5,fontproperties=JBM,y=0.99)
fig.tight_layout(rect=[0,0,1,0.96])
fig.savefig("/mnt/user-data/outputs/solar-glow-drh-gerber-preview.png",dpi=200,facecolor="#000")
print("saved gerber preview")

# ---------- validate Gerber syntax with gerbonara ----------
try:
    from gerbonara import GerberFile, ExcellonFile
    for f in ["GTL","GBL","GTS","GBS","GKO","GTO","GBO"]:
        g=GerberFile.open(os.path.join(OUT,f"solar-glow-drh.{f}")); n=len(list(g.objects))
        print(f"  {f}: parsed OK, {n} objects")
    d=ExcellonFile.open(os.path.join(OUT,"solar-glow-drh.XLN")); print(f"  XLN: parsed OK, {len(list(d.objects))} holes")
    dn=ExcellonFile.open(os.path.join(OUT,"solar-glow-drh-NPTH.XLN")); print(f"  NPTH: parsed OK, {len(list(dn.objects))} holes")
except Exception as e:
    print("gerbonara validate:", repr(e))
