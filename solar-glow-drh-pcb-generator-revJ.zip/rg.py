import re, sys
from shapely.geometry import Polygon, box
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt

def render_gerber(path):
    """Replicate how a fab/viewer renders: sequential LPD(union)/LPC(difference) of G36/G37 regions + D03 flashes."""
    txt=open(path).read()
    aps={}
    for m in re.finditer(r'%ADD(\d+)R,([\d.]+)X([\d.]+)\*%',txt): aps[m.group(1)]=('R',float(m.group(2)),float(m.group(3)))
    for m in re.finditer(r'%ADD(\d+)C,([\d.]+)\*%',txt): aps[m.group(1)]=('C',float(m.group(2)),None)
    img=Polygon(); mode='LPD'; in_region=False; pts=[]; cur_ap=None
    for ln in txt.split('\n'):
        ln=ln.strip()
        if ln=='%LPD*%': mode='LPD'
        elif ln=='%LPC*%': mode='LPC'
        elif ln=='G36*': in_region=True; pts=[]
        elif ln=='G37*':
            if len(pts)>=3:
                try:
                    poly=Polygon(pts).buffer(0)
                    img = img.union(poly) if mode=='LPD' else img.difference(poly)
                except Exception: pass
            in_region=False; pts=[]
        elif re.fullmatch(r'D\d+\*',ln): cur_ap=ln[1:-1]
        else:
            m=re.match(r'X(-?\d+)Y(-?\d+)D0([123])\*',ln)
            if m:
                x=int(m.group(1))/1e6; y=int(m.group(2))/1e6; d=m.group(3)
                if in_region: pts.append((x,y))
                elif d=='3' and cur_ap in aps:
                    t,w,h=aps[cur_ap]
                    fl=box(x-w/2,y-h/2,x+w/2,y+h/2) if t=='R' else __import__('shapely.geometry',fromlist=['Point']).Point(x,y).buffer(w/2)
                    img = img.union(fl) if mode=='LPD' else img.difference(fl)
    return img

def draw(geom, fn, fg='#d9a520', bg='#3a1a52', title='', crop=None, dpi=95):
    fig,ax=plt.subplots(figsize=(6,10)); ax.set_facecolor(bg)
    for poly in (geom.geoms if hasattr(geom,'geoms') else [geom]):
        if poly.is_empty: continue
        ax.fill(*poly.exterior.xy,facecolor=fg,edgecolor='none')
        for r in poly.interiors: ax.fill(*r.xy,facecolor=bg,edgecolor='none')
    if crop: ax.set_xlim(crop[0],crop[1]); ax.set_ylim(crop[2],crop[3])
    else: ax.set_xlim(0,50.8); ax.set_ylim(0,89)
    ax.set_aspect('equal'); ax.axis('off'); ax.set_title(title,fontsize=9)
    plt.tight_layout(); plt.savefig(fn,dpi=dpi); plt.close()

if __name__=='__main__':
    for lay in ['GBS','GBL','GBO']:
        g=render_gerber(f'/home/claude/gerber/solar-glow-drh.{lay}')
        print(f"{lay}: {g.geom_type}, area={g.area:.1f}mm2, bounds={tuple(round(v,1) for v in g.bounds)}")
