#!/usr/bin/env python3
"""SOLAR-GLOW DRH REV J - routing pass.
Adds GND pours (both layers), stitching vias, and net-tagged traces on top of the
REV J placement. Verifies with a geometric connectivity check (each net's copper
forms one electrical island across via-linked layers) and a short/clearance check
(no different-net copper closer than the design rule). Renders both layers."""
import matplotlib, math
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, FancyBboxPatch, RegularPolygon, Annulus
from matplotlib.font_manager import FontProperties
from shapely.geometry import Polygon, Point, LineString, box
from shapely.ops import unary_union
from shapely import affinity

W,H,R = 50.8, 88.9, 3.0
CLR = 0.15          # DRC check floor (tolerates inherent 0.4mm-QFN pitch @0.15)
POUR_CLR = 0.16     # pour + controlled copper clearances -> >= 6mil (0.1524mm) with margin
TW  = 0.22          # default trace width
TWP = 0.45
TWN = 0.16   # narrow QFN escape           # power trace width (VS/GND/MID)
VIA_D, VIA_PAD = 0.3, 0.7
CU="#caa044"; MASK="#0e2f1c"; BODY="#3a4750"; SILK="#e6edf1"; SOLARC="#16314f"; HOLE="#0b0c10"
POUR_B="#3a2f18"; POUR_F="#2f2a16"
NETCOL={"VS":"#e0a83a","GND":"#6b7682","MID":"#d98a4f","VIN":"#caa044","UPDI":"#6fa0e0",
        "SDA":"#5bb0d0","SCL":"#3f88c5","BTN":"#d06fa0",
        "K2":"#4fb0a0","K3":"#4fb0a0","K4":"#4fb0a0","K5":"#4fb0a0",
        "L2":"#9a6cd0","L3":"#9a6cd0","L4":"#9a6cd0","L5":"#9a6cd0",
        "X1":"#8a9a4f","X2":"#8a9a4f","X3":"#8a9a4f",
        "VBAT":"#c060c0","VBATD":"#d884d8","BMID":"#a070d0"}
def fpr(b=False):
    try: return FontProperties(family="DejaVu Sans", weight="bold" if b else "normal")
    except Exception: return FontProperties()

def FP(kind):
    if kind=="LED":   return dict(pads=[("A",-1.3,-0.4,0.65,0.7,"r"),("K",1.3,0.4,0.65,0.7,"r")],body=("c",0,0,2.5),win=2.1)  # LA P47F rev-mount: Ø2.5 flange, Ø2.1 lens, ~0.7 pads on diagonal (2.6 c-c). A=anode(VS), K=cathode(LRET)
    if kind=="SCPC":  return dict(pads=[("P",16.5,6.25,3.5,3.5,"r"),("N",-16.5,-6.25,3.5,3.5,"r")],body=("r",0,0,28.5,17))  # WS10 datasheet land: two 3.5x3.5 pads on diagonal, 36.5x16 outer span (centres +/-16.5,+/-6.25); P=+ end
    if kind=="SOLAR": return dict(pads=[("P",18,0,3.5,3.5,"o"),("N",-18,0,3.5,3.5,"o"),("Pt",21.1,0,4.0,3.0,"rr"),("Nt",-21.1,0,4.0,3.0,"rr")],body=("r",0,0,42,23))  # Pt/Nt = hand-solder access tabs poking past the cell short edges
    if kind=="DOME":  return dict(pads=[("C",0,0,4.9,4.9,"o"),("RING",0,0,11.18,1.0,"ring")],body=("c",0,0,12.0))
    if kind=="PROG":  return dict(pads=[("1",0,2.54,1.5,2.0,"r"),("2",0,0,1.5,2.0,"r"),("3",0,-2.54,1.5,2.0,"r")])
    if kind=="SOD":   return dict(pads=[("K",-1.85,0,1.0,1.2,"r"),("A",1.85,0,1.0,1.2,"r")],body=("r",0,0,3.7,1.6))
    if kind=="RTNR":  # Keystone 3012/3092 SMT coin-cell retainer, 16mm (CR1620/DL1632=CR1632), FIG.2 Low Profile.
        # Land per K75 p11 datasheet (3012/3092, FIG.2): W=23.2 outer tail span, A=16.9 body. Tail pads F=.125"(3.2) SQ; centres +/-10.0 so outer edge=W/2=11.6.
        # Centre NEG pad P=.156"(4.0) SQ MIN; built 9mm-dia round for robust 16mm-cell contact (exceeds min, clears tails). L=15.1 clip body, H=4.0.
        # F=3.2mm SQ min negative (cell-bottom) pad -> enlarged to O9 round for solid contact. clip body L=15.1. Natural orient: tails(+clip) along X.
        return dict(pads=[("T1",-10.0,0,3.2,3.5,"r"),("T2",10.0,0,3.2,3.5,"r"),("NEG",0,0,9.0,9.0,"o")],body=("r",0,0,23.2,15.1))
    if kind=="SOIC8":
        pads=[("1",-2.6,1.905,1.55,0.6,"r"),("2",-2.6,0.635,1.55,0.6,"r"),("3",-2.6,-0.635,1.55,0.6,"r"),("4",-2.6,-1.905,1.55,0.6,"r"),
              ("5",2.6,-1.905,1.55,0.6,"r"),("6",2.6,-0.635,1.55,0.6,"r"),("7",2.6,0.635,1.55,0.6,"r"),("8",2.6,1.905,1.55,0.6,"r")]
        return dict(pads=pads,body=("r",0,0,4.9,3.9))   # ALD910025 dual SAB MOSFET, SOIC-8 (SAL pkg)
    if kind=="0402":  return dict(pads=[("1",-0.51,0,0.59,0.66,"r"),("2",0.51,0,0.59,0.66,"r")],body=("r",0,0,1.0,0.5))
    if kind=="0805":  return dict(pads=[("1",-0.95,0,1.0,1.2,"r"),("2",0.95,0,1.0,1.2,"r")],body=("r",0,0,2.0,1.25))
    if kind=="1206":  return dict(pads=[("1",-1.5,0,1.1,1.7,"r"),("2",1.5,0,1.1,1.7,"r")],body=("r",0,0,3.2,1.6))
    if kind=="TP":    return dict(pads=[("1",0,0,2.0,2.0,"o")])
    if kind=="QFN":
        pads=[]; p=0.4; row=1.45
        for i in range(5): pads.append((str(i+1),-row,-(i-2)*p,0.55,0.25,"r"))
        for i in range(5): pads.append((str(i+6),(i-2)*p,-row,0.25,0.55,"r"))
        for i in range(5): pads.append((str(i+11),row,(i-2)*p,0.55,0.25,"r"))
        for i in range(5): pads.append((str(i+16),-(i-2)*p,row,0.25,0.55,"r"))
        pads.append(("EP",0,0,1.7,1.7,"r")); return dict(pads=pads,body=("r",0,0,3,3))

P=[
 ("PV1","SOLAR",25.4,73.0,0,"F",{"P":"VIN","N":"GND","Pt":"VIN","Nt":"GND"}),
 ("SW1","DOME",40.4,11.0,0,"F",{"C":"BTN","RING":"GND"}),                 # dome is now a user button -> MCU input (no longer the shared LED return)
 ("TP2","TP",12.4,39.25,0,"F",{"1":"GND"}),("TP3","TP",18.9,39.25,0,"F",{"1":"GND"}),
 ("TP5","TP",25.4,39.25,0,"F",{"1":"GND"}),("TP4","TP",31.9,39.25,0,"F",{"1":"GND"}),
 ("TP1","TP",38.4,39.25,0,"F",{"1":"VS"}),
 ("TP6","TP",5.9,39.25,0,"F",{"1":"GND"}),("TP7","TP",44.9,39.25,0,"F",{"1":"VIN"}),  # row: GND VS GND GND GND VS VIN  (3 mid pts parked on GND for now; reserved for spare-GPIO breakout)
 ("SC1","SCPC",15.5,67.5,270,"B",{"P":"VS","N":"MID"}),
 ("SC2","SCPC",35.3,67.5,90,"B",{"P":"MID","N":"GND"}),
 ("D2","LED",18.2,45.0,0,"B",{"A":"VS","K":"K2"}),("D3","LED",23.0,45.0,0,"B",{"A":"VS","K":"K3"}),
 ("D4","LED",27.8,45.0,0,"B",{"A":"VS","K":"K4"}),("D5","LED",32.6,45.0,0,"B",{"A":"VS","K":"K5"}),
 ("R1","1206",18.2,40.0,270,"B",{"1":"K2","2":"L2"}),("R2","1206",23.0,40.0,270,"B",{"1":"K3","2":"L3"}),
 ("R3","1206",27.8,40.0,270,"B",{"1":"K4","2":"L4"}),("R4","1206",32.6,40.0,270,"B",{"1":"K5","2":"L5"}),
 ("D1","SOD",30.0,35.5,0,"B",{"K":"VS","A":"VIN"}),
 ("C2","0805",22.0,35.5,0,"B",{"1":"VS","2":"GND"}),("C3","0805",38.0,35.5,0,"B",{"1":"VS","2":"GND"}),
 # U1 ATtiny1616 - VQFN-20, footprint pad# = datasheet pin# (offset 0, VERIFIED vs DS40002204A).
 # Drives (per-LED PWM): 15=PC0=L2->D2 (TCB0 WO, alt route via PORTMUX) ; 14/13/12 = PB0/PB1/PB2 = L3/L4/L5->D3/D4/D5 = TCA0 split WO0/WO1/WO2.
 #   NB datasheet: PB3 (pad 11) is only TCA0 WO0-alternate, NOT WO3 -> can't be a 4th independent channel, so the 4th LED moved to PC0/TCB0 and pad 11 is freed.
 # 8=PA7=BTN. 20=PA1=SDA, 1=PA2=SCL (I2C on the ALTERNATE TWI position -> firmware must set PORTMUX TWIROUTEA; default SDA/SCL on PB1/PB0 are the drives). 19=PA0=UPDI. 4=VDD, 3/EP=GND.
 # AVAILABLE: 2=PA3(=TCA0 WO3), 5/6/7=PA4/5/6, 9/10/11=PB5/PB4/PB3, 16/17/18=PC1/2/3.
 ("U1","QFN",11.5,27.0,0,"B",{"3":"GND","4":"VS","19":"UPDI","20":"SDA","1":"SCL","8":"BTN","12":"L5","13":"L4","14":"L3","15":"L2","EP":"GND"}),
 ("C1","0805",9.3,24.0,0,"B",{"1":"VS","2":"GND"}),     # U1 decoupling, moved left-below U1 to free the PB0-3 fan-out
 # ALD910025 dual SAB MOSFET (SAL/SOIC-8): 1=IC*(V-) 2=GN1 3=DN1 4=SN1 | 5=SN2/V- 6=DN2 7=GN2 8=V+
 # M1(left)//SC1: G+D(2,3)->VS, S(4)->MID ; M2(right)//SC2: G+D(6,7)->MID, S(5)->GND ; V+(8)->VS, V-/IC*(1,5)->GND
 ("U2","SOIC8",30.0,50.7,0,"B",{"1":"GND","2":"VS","3":"VS","4":"MID","5":"GND","6":"MID","7":"MID","8":"VS"}),
 ("JP1","PROG",38.0,26.0,0,"B",{"1":"SDA","2":"SCL","3":"GND"}),          # repurposed: 3-pin I2C breakout (SDA/SCL/GND); VS is one pad away on J1.2 and on the TP row
 ("J1","PROG",6.6,27.0,0,"B",{"1":"UPDI","2":"VS","3":"GND"}),
 # ===== REV J: hidden dual-coin battery option (ALTERNATIVE to PV1 - SOLAR or BATTERY, never both). 2x 3V coins in series -> 2x Si diode (~1.1-1.2V) -> VS =====
 # series: BT1.neg=stack(-)->GND .. BT1.clip(+)--BMID--BT2.neg(-) .. BT2.clip(+)=stack(+)->VBAT->D6->D7->VS
 ("BT1","RTNR",17.4,73.0,90,"F",{"T1":"BMID","T2":"BMID","NEG":"GND"}),   # left retainer (cell A), tails along Y
 ("BT2","RTNR",33.4,73.0,90,"F",{"T1":"VBAT","T2":"VBAT","NEG":"BMID"}),  # right retainer (cell B)
 ("D6","SOD",25.4,76.0,90,"B",{"A":"VBAT","K":"VBATD"}),                   # MMSD4148 #1 (REAR, in the SC1/SC2 gap under the panel)
 ("D7","SOD",25.4,70.0,90,"B",{"A":"VBATD","K":"VS"}),                      # MMSD4148 #2 -> VS (REAR, in the gap)
 ("C4","0402",14.5,50.5,0,"B",{"1":"VS","2":"GND"}),                        # battery-rail bypass: Samsung 0402 1uF 10V X7S (CL05Y105KP6VPN) (REAR, on the VS bus)
]
def rot(x,y,d): a=math.radians(d); c,s=math.cos(a),math.sin(a); return (x*c-y*s, x*s+y*c)

pad_xy={}; pad_net={}; pad_shape={}; abs_pads=[]
for ref,kind,ox,oy,rd,side,nm in P:
    for (pn,px,py,w,h,sh) in FP(kind)["pads"]:
        rx,ry=rot(px,py,rd)
        if rd in (90,270): w,h=h,w
        x,y=ox+rx,oy+ry; net=nm.get(pn,"?")
        pad_xy[(ref,pn)]=(x,y,side); pad_net[(ref,pn)]=net; pad_shape[(ref,pn)]=(w,h,sh)
        abs_pads.append((ref,pn,net,x,y,w,h,sh,side))
def p(ref,pn): x,y,_=pad_xy[(ref,pn)]; return (x,y)

# ---------------- VIAS (net,x,y) ----------------
VIAS=[
 # GND stitching grid (catch every pour fragment) + EP + dome
 ("GND",5,82),("GND",46,82),("GND",40,87),("GND",5,60),("GND",46.3,60),("GND",5,44),("GND",46.3,44),
 ("GND",25,56),("GND",5,31),("GND",46.3,31),("GND",31,21),("GND",5,15),("GND",46,15),("GND",23,17),
 ("GND",9,4),("GND",5,7),("GND",46,7),("GND",25,6),("GND",11.5,27),("GND",38.0,6.0),("GND",5.4,40.0),
 # ---- per-LED drives L2-L5: back escape-fan from the QFN right edge to spread vias (C1 moved out of the way), then FRONT up to the ballasts ----
 ("L2",14.0,30.0),("L2",18.2,37.5),
 ("L3",14.95,30.0),("L3",23.0,37.5),
 ("L4",15.9,30.0),("L4",27.8,37.5),
 ("L5",16.85,30.0),("L5",32.6,37.75),
 # ---- dome push-button -> MCU PA7 (C pad front->back; back trace then clears the QR/shield) ----
 ("BTN",40.4,11.0),
 # ---- I2C breakout GND stitch by JP1 ----
 ("GND",41.0,23.0),
 # UPDI escape via + J1
 ("UPDI",11.3,29.2),("UPDI",6.6,29.0),
 # castellation front-hop vias (on the SDA/SCL back verticals -> front run to the edge teeth)
 ("SDA",37.5,30.0),("SCL",39.5,28.5),
 # VS TP1
 ("VS",40.0,48.0),("VS",43.0,33.0),
 # U2 V+ (pin8) front drop to clear the MID trace
 ("VS",33.8,52.6),("VS",33.8,48.0),
 # C1 (U1 decoupling) relocated to (8.7,24), left-below U1; VS feed is all back-side (taps VDD feed) -> no via
 ("VIN",45.4,40.0),
 ("VBAT",33.4,80.0),    # REV J: VBAT front(BT2 clip)->back to the rear diodes
 ("GND",16.5,50.5),    # REV J: C4 low-side GND stitch (rear)
]
# ---------------- CASTELLATIONS (plated half-holes on the RIGHT edge x=W) : module solder-down + I2C/power bus ----------------
# (net, x, y).  x=W so the board outline bisects each hole -> gold half-barrel + inner pad.
CAST_D, CAST_PAD = 0.9, 1.6
CAST = [
 ("VS",  W, 31.4),
 ("SDA", W, 29.2),
 ("SCL", W, 27.0),
 ("GND", W, 24.8),
 ("GND", W, 22.6),
]
# ---------------- TRACES (net,layer,[pts],width) ; pts = (ref,pn) or (x,y) ----------------
T=[
 # ===== BACK feeders =====
 ("MID","B",[p("SC1","N"),(7.5,85.0),(27.3,85.0),p("SC2","P")],TWP),
 # ----- U2 SAB balancer wiring (TWN, uA-class). M1=left col, M2=right col. GND pins 1,5 via pour -----
 ("VS","B",[p("U2","2"),p("U2","3")],TWN),                                  # tie M1 gate+drain
 ("VS","B",[p("U2","3"),(26.0,50.065),(26.0,48.0)],TWN),                    # M1 G/D down to VS bus (clears pin4)
 ("VS","B",[p("U2","8"),(33.8,52.6)],TWN),                                  # V+ stub to via
 ("VS","F",[(33.8,52.6),(33.8,48.0)],TWN),                                  # V+ drops to front, down to bus via (clears MID on back)
 ("MID","B",[p("U2","6"),p("U2","7")],TWN),                                 # tie M2 gate+drain
 ("MID","B",[p("U2","4"),(27.4,49.4),(32.6,49.4),p("U2","6")],TWN),         # M1 source under body to M2 G/D
 ("MID","B",[p("U2","7"),(34.5,51.335),(34.5,82.0),(29.05,82.0),p("SC2","P")],TWN),  # MID up to SC2 mid node
 ("VS","B",[p("SC1","P"),(23.5,48.0),(8.0,48.0)],TWP),
 ("VS","B",[(8.0,48.0),(41.0,48.0)],TWP),
 ("VS","B",[(16.9,48.0),p("D2","A")],TW),("VS","B",[(21.7,48.0),p("D3","A")],TW),
 ("VS","B",[(26.5,48.0),p("D4","A")],TW),("VS","B",[(31.3,48.0),p("D5","A")],TW),
 ("VS","B",[(8.0,48.0),(8.0,33.0)],TWP),                 # bus->rail at left (frees right side for VIN)
 ("VS","B",[(8.0,33.0),(43.0,33.0)],TW),  # VS rail solid (old RETD gap closed; LED drives now cross on the front)
 ("VS","F",[(43.0,33.0),(43.0,40.0),(40.0,40.0)],TW),  # right half fed up at x43 (right of the name AND right of the RET jumper loop) into the existing TP1->bus front run
 ("VS","B",[(36.5,33.0),p("C3","1")],TW),("VS","B",[(28.15,33.0),p("D1","K")],TW),("VS","B",[(20.5,33.0),p("C2","1")],TW),
 ("VS","B",[(8.5,26.6),(8.5,24.0),(8.35,24.0),p("C1","1")],TW),    # tap the VDD feed down to C1.1 (7.75,24)
 ("VS","B",[(8.5,33.0),(8.5,26.6),p("U1","4")],TW),       # down to MCU VDD (UPDI is on front now)
 ("VS","B",[(8.5,27.0),(6.6,27.0),p("J1","2")],TW),       # to J1 VCC
 ("VS","F",[p("TP1","1"),(40.0,40.0),(40.0,48.0)],TW),    # TP1(VS) up to y48 rail
 ("VIN","F",[p("PV1","P"),(45.4,73.0),(45.4,40.0)],TWP),
 ("VIN","F",[(45.4,40.0),(44.9,39.25)],TW),    # VIN lead terminates in TP7 (row), not a standalone pad
 ("VIN","B",[(45.4,40.0),(45.4,37.0),(31.85,37.0),p("D1","A")],TW),
 ("UPDI","B",[p("U1","19"),(11.3,29.2)],TWN),              # escape up to via
 ("UPDI","B",[(6.6,29.0),p("J1","1")],TW),                # J1 via -> J1.1
 # ===== individual-LED return path (replaces the LRET/RET/RETD group) =====
 # cathodes K2-K5: each LED cathode down to its own ballast top (no shared collector now)
 ("K2","B",[p("D2","K"),(19.5,41.5),p("R1","1")],TW),("K3","B",[p("D3","K"),(24.3,41.5),p("R2","1")],TW),
 ("K4","B",[p("D4","K"),(29.1,41.5),p("R3","1")],TW),("K5","B",[p("D5","K"),(33.9,41.5),p("R4","1")],TW),
 # drives L2-L5: ballast bottom -> via -> FRONT staircase across the VS rail -> via -> back -> MCU PBx (TCA0 WO0-3)
 ("L2","B",[p("U1","15"),(14.0,27.8),(14.0,30.0)],TWN),("L2","F",[(14.0,30.0),(14.0,35.0),(18.2,35.0),(18.2,37.5)],TW),("L2","B",[(18.2,37.5),p("R1","2")],TW),
 ("L3","B",[p("U1","14"),(14.95,27.4),(14.95,30.0)],TWN),("L3","F",[(14.95,30.0),(14.95,34.6),(23.0,34.6),(23.0,37.5)],TW),("L3","B",[(23.0,37.5),p("R2","2")],TW),
 ("L4","B",[p("U1","13"),(15.9,27.0),(15.9,30.0)],TWN),("L4","F",[(15.9,30.0),(15.9,34.2),(27.8,34.2),(27.8,37.5)],TW),("L4","B",[(27.8,37.5),p("R3","2")],TW),
 ("L5","B",[p("U1","12"),(16.85,26.6),(16.85,30.0)],TWN),("L5","F",[(16.85,30.0),(16.85,33.8),(32.6,33.8),(32.6,37.75)],TW),("L5","B",[(32.6,37.75),p("R4","2")],TW),
 # I2C (SDA/SCL): MCU -> JP1, back, below the rail
 ("SDA","B",[p("U1","20"),(10.45,28.9),(10.45,31.7),(37.5,31.7),(37.5,28.54),p("JP1","1")],TW),
 ("SCL","B",[p("U1","1"),(10.05,32.2),(39.5,32.2),(39.5,26.0),p("JP1","2")],TW),
 # dome button -> MCU PA7: C-pad via to back, up clear of the dome, left above the QR/shield, into PA7
 ("BTN","B",[p("SW1","C"),(40.4,22.0),(20.5,22.0),(20.5,24.0),(12.0,24.0),p("U1","8")],TW),
 # ===== FRONT: UPDI via->via (kept) =====
 ("UPDI","F",[(11.3,29.2),(6.6,29.0)],TW),
 # ===== castellated edge connector (right edge) : GND teeth pour-fed; VS off the rail; SDA/SCL hop to the front to clear the JP1 corner =====
 ("VS","B",[(43.0,33.0),(48.0,33.0),(48.0,31.4),(W,31.4)],TW),                 # rail -> VS tooth (top); drops at x48, east of the GND stitch via
 ("SDA","F",[(37.5,30.0),(49.0,30.0),(49.0,29.2),(W,29.2)],TW),                # via off SDA's vertical -> front -> SDA tooth
 ("SCL","F",[(39.5,28.5),(49.5,28.5),(49.5,27.0),(W,27.0)],TW),                # via off SCL's vertical -> front -> SCL tooth
 # ===== REV J battery traces — diodes + C4 are REAR now (under the panel / with the passives); only the retainer clips stay front =====
 ("BMID","F",[p("BT1","T2"),(22.5,83.0),(22.5,63.0),p("BT1","T1")],TW),       # link BT1 clip tails around its NEG pad (front)
 ("BMID","F",[(22.5,73.0),p("BT2","NEG")],TW),                                 # BMID across the gap to BT2 negative (front)
 ("VBAT","F",[p("BT2","T2"),(38.5,83.0),(38.5,63.0),p("BT2","T1")],TW),        # link BT2 clip tails around its NEG pad (front)
 ("VBAT","F",[p("BT2","T2"),(33.4,80.0)],TW),                                  # short front stub from BT2 top tail to the VBAT via
 ("VBAT","B",[(33.4,80.0),(25.4,80.0),p("D6","A")],TW),                         # via -> back -> over into the SC1/SC2 gap to D6 anode
 ("VBATD","B",[p("D6","K"),p("D7","A")],TW),                                    # between the two series diodes (rear, in the gap)
 ("VS","B",[p("D7","K"),(25.7,60.0),(25.7,48.0)],TW),                           # D7 cathode -> down the gap (right of the GND stitch via @25,56) -> VS bus
 ("VS","B",[p("C4","1"),(13.99,48.0)],TW),                                      # C4 hi side -> VS bus (rear)
 ("GND","B",[p("C4","2"),(16.5,50.5)],TW),                                      # C4 low side -> rear GND stitch via
]

# ---------------- geometry builders ----------------
def pad_poly(x,y,w,h,sh,grow=0.0):
    if sh in("o","ring"): return Point(x,y).buffer(w/2+grow,resolution=24)
    if sh=="rr":
        r=min(w,h)*0.30
        rr=box(x-w/2+r,y-h/2+r,x+w/2-r,y+h/2-r).buffer(r,join_style=1,resolution=16)
        return rr.buffer(grow,join_style=1) if grow else rr
    return box(x-w/2-grow,y-h/2-grow,x+w/2+grow,y+h/2+grow)
def trace_poly(pts,wd,grow=0.0): return LineString(pts).buffer(wd/2+grow,cap_style=1,join_style=1,resolution=12)
def via_poly(x,y,grow=0.0): return Point(x,y).buffer(VIA_PAD/2+grow,resolution=24)

# copper per (net,layer)
def build_copper(grow=0.0):
    cu={}
    def add(net,layer,geom): cu.setdefault((net,layer),[]).append(geom)
    for ref,pn,net,x,y,w,h,sh,side in abs_pads:
        lay = "F" if side=="F" else "B"
        if pn=="RING": add(net,lay,Point(x,y).buffer(5.59+grow).difference(Point(x,y).buffer(5.59-1.0-grow)))
        else: add(net,lay,pad_poly(x,y,w,h,sh,grow))
    for net,lay,pts,wd in T: add(net,lay,trace_poly(pts,wd,grow))
    for net,x,y in VIAS:
        add(net,"F",via_poly(x,y,grow)); add(net,"B",via_poly(x,y,grow))
    for net,x,y in CAST:           # plated half-holes: annular pad on both layers (clipped to the board edge downstream)
        add(net,"F",Point(x,y).buffer(CAST_PAD/2+grow,resolution=24)); add(net,"B",Point(x,y).buffer(CAST_PAD/2+grow,resolution=24))
    return {k:unary_union(v) for k,v in cu.items()}

# GND pour: board minus edge minus clearance halo around all non-GND copper (per layer)
def board_poly(): return box(0,0,W,H)  # rounded corners ignored for pour calc (conservative)
def build_pours():
    cu=build_copper(0.0); pours={}
    from shapely.geometry import box as _box
    for lay in ("F","B"):
        region=board_poly().buffer(-0.4)   # edge clearance
        if lay=="F": region=region.difference(_box(6.0,28.6,13.0,30.7))  # keep pour out of QFN escape
        non_gnd=[g for (n,l),g in cu.items() if l==lay and n!="GND"]
        if non_gnd: region=region.difference(unary_union(non_gnd).buffer(POUR_CLR))
        pours[lay]=region
    return pours

# ---------------- CONNECTIVITY: per net, copper islands joined by vias ----------------
def connectivity():
    cu=build_copper(0.0); pours=build_pours()
    # add pours to GND copper
    cu[("GND","F")]=unary_union([cu.get(("GND","F"),Point(0,0).buffer(0)),pours["F"]])
    cu[("GND","B")]=unary_union([cu.get(("GND","B"),Point(0,0).buffer(0)),pours["B"]])
    report={}
    nets=sorted({n for (n,l) in cu if n not in ("?","NC")})
    for net in nets:
        pieces=[]  # (layer, polygon)
        for lay in ("F","B"):
            g=cu.get((net,lay))
            if g is None or g.is_empty: continue
            geoms=list(g.geoms) if g.geom_type=="MultiPolygon" else [g]
            for gg in geoms: pieces.append([lay,gg])
        # union-find over pieces; vias bridge layers if via touches a piece on each layer
        parent=list(range(len(pieces)))
        def find(a):
            while parent[a]!=a: parent[a]=parent[parent[a]]; a=parent[a]
            return a
        def uni(a,b): parent[find(a)]=find(b)
        for vnet,vx,vy in VIAS:
            if vnet!=net: continue
            vp=Point(vx,vy)
            touch=[i for i,(lay,poly) in enumerate(pieces) if poly.distance(vp)<0.2]
            for i in touch[1:]: uni(touch[0],i)
        # also same-layer pieces that overlap are already merged by unary_union; cross-layer only via vias
        # assign pads to pieces
        comp_of_pad={}
        for (ref,pn),(px,py,side) in pad_xy.items():
            if pad_net[(ref,pn)]!=net: continue
            lay="F" if side=="F" else "B"
            pt=Point(px+5.0,py) if pn=="RING" else Point(px,py)   # ring: test a point on the annulus
            hit=[i for i,(l,poly) in enumerate(pieces) if l==lay and poly.distance(pt)<0.05]
            comp_of_pad[(ref,pn)]= find(hit[0]) if hit else None
        comps=set(c for c in comp_of_pad.values())
        unrouted=[k for k,c in comp_of_pad.items() if c is None]
        report[net]=(len([c for c in comps if c is not None]), len(comp_of_pad), unrouted)
    return report

# ---------------- SHORTS: different-net copper within clearance ----------------
def shorts():
    OFFX=20.0
    cu=build_copper(0.0); pours=build_pours()
    cu[("GND","F")]=unary_union([cu.get(("GND","F"),Point(0,0).buffer(0)),pours["F"]])
    cu[("GND","B")]=unary_union([cu.get(("GND","B"),Point(0,0).buffer(0)),pours["B"]])
    # build per-(net,layer) but split pads by ref so we can ignore intra-package pitch
    viol=[]
    for lay in ("F","B"):
        items=[(n,g) for (n,l),g in cu.items() if l==lay and not g.is_empty and n not in ("?","NC")]
        for i in range(len(items)):
            for j in range(i+1,len(items)):
                (n1,g1),(n2,g2)=items[i],items[j]
                if n1==n2: continue
                d=g1.distance(g2)
                if d<CLR-1e-3:
                    from shapely.ops import nearest_points
                    pa,pb=nearest_points(g1,g2); mx,my=(pa.x+pb.x)/2,(pa.y+pb.y)/2
                    viol.append((lay,n1,n2,round(d,3),round(mx-OFFX,1) if False else round(mx,1),round(my,1)))
    return viol

print("=== CONNECTIVITY (islands / pads / unrouted) ===")
rep=connectivity(); ok=True
for net in ["GND","VS","MID","VIN","UPDI","SDA","SCL","BTN","K2","K3","K4","K5","L2","L3","L4","L5","VBAT","VBATD","BMID"]:
    isl,npad,unr=rep[net]; flag="OK" if isl==1 and not unr else "**"
    if isl!=1 or unr: ok=False
    print(f"  {net:5s}: islands={isl} pads={npad} {flag}"+(f" unrouted={unr}" if unr else ""))
print("  ALL NETS CONNECTED" if ok else "  >>> some nets not single-island")
print("=== SHORTS (clearance < %.2fmm) ==="%CLR)
v=shorts()
if not v: print("  none")
else:
    for lay,n1,n2,d,mx,my in v:
        print(f"  {lay}: {n1:5s}<->{n2:5s} gap={d}mm  near kicad=({mx},{my})  board=({mx-20:.1f},{my-20:.1f})")

# ---------------- RENDER (both layers, first routing pass) ----------------
def render():
    pours=build_pours()
    fig,(axF,axB)=plt.subplots(1,2,figsize=(11,10)); fig.patch.set_facecolor("#08090c")
    for ax,lay,title in [(axF,"F","FRONT  ·  copper + pour (first route)"),(axB,"B","BACK  ·  copper + pour (first route)")]:
        ax.add_patch(FancyBboxPatch((0,0),W,H,boxstyle=f"round,pad=0,rounding_size={R}",fc="#0c0d11",ec="#2b2f37",lw=1.4))
        # pour
        pr=pours[lay]; geoms=list(pr.geoms) if pr.geom_type=="MultiPolygon" else [pr]
        for g in geoms:
            xs,ys=g.exterior.xy; ax.fill(xs,ys,color=(POUR_F if lay=="F" else POUR_B),zorder=1,alpha=0.9)
            for ring in g.interiors: ax.fill(*ring.xy,color="#0c0d11",zorder=1)
        # traces
        for net,l,pts,wd in T:
            if l!=lay: continue
            xs=[q[0] for q in pts]; ys=[q[1] for q in pts]
            ax.plot(xs,ys,color=NETCOL.get(net,CU),lw=wd*3.2,solid_capstyle="round",solid_joinstyle="round",zorder=4,alpha=0.95)
        # pads
        for ref,pn,net,x,y,w,h,sh,side in abs_pads:
            if ("F" if side=="F" else "B")!=lay: continue
            col=NETCOL.get(net,"#555")
            if pn=="RING": ax.add_patch(Annulus((x,y),5.59,1.0,fc=NETCOL["GND"],ec="#e9d49a",lw=0.3,zorder=5)); continue
            if sh in("o",): ax.add_patch(Circle((x,y),w/2,fc=col,ec="#e9d49a",lw=0.3,zorder=6))
            else: ax.add_patch(Rectangle((x-w/2,y-h/2),w,h,fc=col,ec="#e9d49a",lw=0.3,zorder=6))
        # LED windows (keepout) on both layers
        for ref,kind,ox,oy,rd,side,nm in P:
            if kind=="LED": ax.add_patch(Circle((ox,oy),1.05,fc=MASK,ec="#1c5436",lw=0.5,zorder=3))
        # vias
        for net,x,y in VIAS:
            ax.add_patch(Circle((x,y),VIA_PAD/2,fc="#d8c89a",ec="#7a6a3a",lw=0.3,zorder=7))
            ax.add_patch(Circle((x,y),VIA_D/2,fc="#0c0d11",zorder=8))
        # silk: ref + component outline (this side)
        for ref,kind,ox,oy,rd,side,nm in P:
            if ("F" if side=="F" else "B")!=lay: continue
            b=FP(kind).get("body")
            if b:
                if b[0]=="r":
                    w2,h2=(b[4],b[3]) if rd in (90,270) else (b[3],b[4])
                    ax.add_patch(Rectangle((ox-w2/2,oy-h2/2),w2,h2,fill=False,ec=SILK,lw=0.4,alpha=0.5,zorder=9))
                else: ax.add_patch(Circle((ox,oy),b[3]/2,fill=False,ec=SILK,lw=0.4,alpha=0.5,zorder=9))
            ax.text(ox,oy,ref,ha="center",va="center",fontsize=4.0,color=SILK,fontproperties=fpr(True),zorder=10)
        if lay=="F":
            from qr_front import QNF as _QNF, QDARKF as _QDARKF
            cx,cy,S=15.0,15.5,18.0; ms=S/_QNF
            ax.add_patch(Rectangle((cx-S/2,cy-S/2),S,S,fc="#c9a227",ec="#7a6a3a",lw=0.4,zorder=10))   # gold ENIG tile
            for (r,c) in _QDARKF:
                ax.add_patch(Rectangle((cx-S/2+c*ms, cy+S/2-(r+1)*ms), ms, ms, fc="#0c0d11", ec="none", zorder=11))
            ax.text(cx, cy-S/2-0.9, "DEVIN R. HOROWITZ, ESQ.", ha="center", va="top", fontsize=3.0, color="#caa84a", zorder=11)
        if lay=="B":
            from qr_back import QN as _QN, QDARK as _QDARK
            cx,cy,S=17.0,14.0,12.0; ms=S/_QN
            ax.add_patch(Rectangle((cx-S/2,cy-S/2),S,S,fc="#c9a227",ec="#7a6a3a",lw=0.4,zorder=10))   # gold ENIG tile (light/quiet zone)
            for (r,c) in _QDARK:
                ax.add_patch(Rectangle((cx-S/2+c*ms, cy+S/2-(r+1)*ms), ms, ms, fc="#0c0d11", ec="none", zorder=11))  # dark modules = black mask
            ax.text(cx, cy-S/2-1.0, "github.com/devinhorowitz", ha="center", va="top", fontsize=3.6, color="#9a8a52", zorder=11)
        ax.set_xlim(-3,W+3); ax.set_ylim(-3,H+6); ax.set_aspect("equal"); ax.axis("off")
        ax.text(W/2,H+3,title,ha="center",fontsize=10.5,fontproperties=fpr(True),color=SILK)
    fig.suptitle("SOLAR-GLOW · DRH — REV J  ·  routed: 19/19 nets, 0 DRC @ 6mil (held)  ·  back QR → github.com/devinhorowitz/solar-business-card",
                 fontsize=10.0,fontproperties=fpr(True),color=SILK,y=0.99)
    plt.tight_layout(rect=[0,0,1,0.96]); plt.savefig("/home/claude/routed.png",dpi=150,facecolor="#08090c"); print("saved routed.png")
render()
