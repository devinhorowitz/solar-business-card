"""Alma-mater logos as solder-mask OPENINGS (exposed gold ENIG over the back GND
pour), mirrored in place so they read from the back like bsilk/QR. Refined for
clean lines and internal symmetry:
 - AJMLS: rim text dropped; bold SHIELD only. Built by mirroring one clean half
   across the vertical axis (the shield is bilaterally symmetric by design), so
   the scales/book/checkered base are perfectly symmetric. Solid gold shield with
   purple heraldry (high contrast on the gold field).
 - SPSU: a true regular rounded hexagon (synthesized), gold, with the purple SPSU
   letters from the source."""
import numpy as np, cv2, math
from PIL import Image
from shapely.geometry import Polygon
from shapely.ops import unary_union
import shapely.affinity as aff

def _b2s(b, eps=0.5):                       # binary (image px, y-down) -> shapely (px, y-down)
    c2, h2 = cv2.findContours(b.astype(np.uint8), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    if h2 is None: return Polygon()
    h2 = h2[0]
    def dep(i):
        k = 0; p = h2[i][3]
        while p != -1: k += 1; p = h2[p][3]
        return k
    pl = []
    for i in range(len(c2)):
        if dep(i) % 2 or len(c2[i]) < 3: continue
        ext = cv2.approxPolyDP(c2[i], eps, True).reshape(-1, 2).astype(float)
        hl = [cv2.approxPolyDP(c2[j], eps, True).reshape(-1, 2).astype(float)
              for j in range(len(c2)) if h2[j][3] == i and len(c2[j]) >= 3]
        try:
            p = Polygon(ext, hl).buffer(0)
            if not p.is_empty: pl.append(p)
        except Exception: pass
    return unary_union(pl)

def _px2mm(g, cxp, cyp, scale, cx, cy, mirror):   # image px (y-down) -> board mm (y-up)
    g = aff.translate(aff.scale(aff.translate(g, -cxp, -cyp), scale, -scale, origin=(0,0)), cx, cy)
    if mirror: g = aff.scale(g, xfact=-1, yfact=1, origin=(cx, cy))   # read from the back
    return g

def ajmls_shield(path, cx, cy, height_mm, mirror=True, thicken_mm=0.0):
    g = np.asarray(Image.open(path).convert("L")).astype(int)
    H, W = g.shape; dark = (g <= 110).astype(np.uint8)
    n, lab, st, ct = cv2.connectedComponentsWithStats(dark, 8); best, ba = None, 0
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if x <= 1 or y <= 1 or x+w >= W-1 or y+h >= H-1: continue
        if abs(ct[i][0]-W/2) > W*.2 or abs(ct[i][1]-H/2) > H*.2: continue
        if a > ba: ba, best = a, i
    mask = (lab == best).astype(np.uint8)
    outer = max(cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0], key=cv2.contourArea)
    sil = np.zeros((H, W), np.uint8); cv2.drawContours(sil, [outer], -1, 1, -1)
    x, y, w, h = cv2.boundingRect(outer); ax = x + w/2.0
    cols = np.arange(W); mc = np.clip(np.round(2*ax-cols).astype(int), 0, W-1); lcol = cols <= ax
    sym = lambda m: np.where(lcol[None,:], m, m[:, mc])           # mirror clean (left) half
    sil_s = sym(sil)
    dleft = (dark & sil).copy(); dleft[:, int(round(ax))+1:] = 0
    d_s = sym(dleft)
    nn, ll, ss, _ = cv2.connectedComponentsWithStats(d_s, 8); d_clean = np.zeros_like(d_s)
    for i in range(1, nn):
        if ss[i, cv2.CC_STAT_AREA] >= 3: d_clean[ll == i] = 1     # drop 1-2px specks only
    gold = (sil_s & (1-d_clean)).astype(np.uint8)
    nn, ll, ss, _ = cv2.connectedComponentsWithStats(gold, 8)
    if nn > 1:
        big = 1 + int(np.argmax([ss[i, cv2.CC_STAT_AREA] for i in range(1, nn)])); gold = (ll == big).astype(np.uint8)
    x2, y2, w2, h2 = cv2.boundingRect(gold); scale = height_mm/h2
    geom = _px2mm(_b2s(gold, 0.45), x2+w2/2, y2+h2/2, scale, cx, cy, mirror)
    geom = geom.simplify(0.018, preserve_topology=True).buffer(0.012, join_style=1).buffer(-0.012, join_style=1)
    if thicken_mm: geom = geom.buffer(thicken_mm).buffer(0)
    return geom

def spsu_hex(path, cx, cy, size_mm, mirror=True, thicken_mm=0.0):
    rgb = np.asarray(Image.open(path).convert("RGB")).astype(int)
    green = ((rgb[:,:,1]-(rgb[:,:,0]+rgb[:,:,2])/2) > 30).astype(np.uint8)
    ff = green.copy(); hh, ww = green.shape; m2 = np.zeros((hh+2, ww+2), np.uint8)
    cv2.floodFill(ff, m2, (0,0), 1); hexf = (green | (1-ff)).astype(np.uint8)
    cnt = max(cv2.findContours(hexf, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[0], key=cv2.contourArea)
    M = cv2.moments(cnt); cxp, cyp = M['m10']/M['m00'], M['m01']/M['m00']
    eps = 0.01*cv2.arcLength(cnt, True); hull = cnt.reshape(-1,2)
    for _ in range(40):
        ap = cv2.approxPolyDP(cnt, eps, True).reshape(-1,2)
        if len(ap) <= 6: hull = ap; break
        eps *= 1.15
    rads = np.hypot(hull[:,0]-cxp, hull[:,1]-cyp); angs = np.arctan2(hull[:,1]-cyp, hull[:,0]-cxp)
    R = float(np.median(rads)); th0 = float(angs[np.argmax(rads)])
    verts = [(cxp+R*math.cos(th0+k*math.pi/3), cyp+R*math.sin(th0+k*math.pi/3)) for k in range(6)]
    cr = 0.10*R
    hexr = Polygon(verts).buffer(-cr, join_style=1).buffer(cr, join_style=1)   # regular rounded hexagon
    white = (rgb.sum(2) > 720).astype(np.uint8); letters = white & hexf
    gold_px = hexr.difference(_b2s(letters, 0.4))
    x, y, w, h = cv2.boundingRect(cnt); scale = size_mm/max(w, h)
    geom = _px2mm(gold_px, cxp, cyp, scale, cx, cy, mirror).simplify(0.012, preserve_topology=True)
    if thicken_mm: geom = geom.buffer(thicken_mm).buffer(0)
    return geom

AJMLS_PATH = "/mnt/user-data/uploads/cropped-AJMLS-Site-Icon-1.png"
SPSU_PATH  = "/mnt/user-data/uploads/SPSU_ICON_RGB.jpg"
AJMLS_POS  = (11.5, 14.6, 15.0)   # cx, cy, height_mm
SPSU_POS   = (45.0, 15.0, 7.5)    # cx, cy, size_mm

def back_logos(mirror=True, thicken_mm=0.0):
    import os
    from shapely import wkt as _wkt
    CACHE = "/home/claude/logos_cache.wkt"
    have_src = os.path.exists(AJMLS_PATH) and os.path.exists(SPSU_PATH)
    if have_src:
        a = ajmls_shield(AJMLS_PATH, *AJMLS_POS, mirror=mirror, thicken_mm=thicken_mm)
        s = spsu_hex(SPSU_PATH, *SPSU_POS, mirror=mirror, thicken_mm=thicken_mm)
        g = unary_union([a, s])
        try: open(CACHE,"w").write(g.wkt)   # cache for sessions where the source images are gone
        except Exception: pass
        return g
    if os.path.exists(CACHE):               # source images unavailable -> use cached vector geometry
        return _wkt.loads(open(CACHE).read())
    import warnings
    warnings.warn("back_logos: source PNGs and cache both absent -> emitting EMPTY logo geometry "
                  "(re-upload cropped-AJMLS-Site-Icon-1.png + SPSU_ICON_RGB.jpg for the back logos)")
    return Polygon()

